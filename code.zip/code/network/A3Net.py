# -*- coding: utf-8 -*-
import torch
import torch.nn as nn
from backbone.origin.from_origin import Backbone_VGG16_in3
from module.BaseBlocks import BasicConv2d
from module.MyModule import *
from utils.tensor_ops import cus_sample
from backbone.origin.res2net_v1b_base import Res2Net_model
from backbone.origin.swin import *
#VGG-16 backbone
class A3Net_VGG16(nn.Module):
    def __init__(self):
        super(A3Net_VGG16, self).__init__()

        self.upsample = cus_sample

        (
            self.encoder1,
            self.encoder2,
            self.encoder4,
            self.encoder8,
            self.encoder16,
        ) = Backbone_VGG16_in3()


        self.Gate1 = CBAM(64)
        self.Gate2 = CBAM(128)
        self.Gate3 = CBAM(256)
        self.Gate4 = CBAM(512)
        self.Gate5 = CBAM(512)


        #1*1 conv change channel
        self.con_AIM5 = nn.Conv2d(512, 64, 3, 1, 1)
        self.con_AIM4 = nn.Conv2d(512, 64, 3, 1, 1)
        self.con_AIM3 = nn.Conv2d(256, 64, 3, 1, 1)
        self.con_AIM2 = nn.Conv2d(128, 64, 3, 1, 1)
        self.con_AIM1 = nn.Conv2d(64, 32, 3, 1, 1)

        # U形结构解码器
        # GAM
        self.gam =GAM(64)
        self.cpa = CPA(64)
        # SIM Module
        self.CSC16 = CSC(64)
        self.CSC8 = CSC(64)
        self.CSC4 = CSC(64)
        self.CSC2 = CSC(32)
        # LAM
        self.lam = LAM(32)

        self.upconv16 = BasicConv2d(64, 64, kernel_size=3, stride=1, padding=1)
        self.upconv8 = BasicConv2d(64, 64, kernel_size=3, stride=1, padding=1)
        self.upconv4 = BasicConv2d(64, 64, kernel_size=3, stride=1, padding=1)
        self.upconv2 = BasicConv2d(64, 32, kernel_size=3, stride=1, padding=1)
        self.upconv1 = BasicConv2d(32, 32, kernel_size=3, stride=1, padding=1)


        self.classifier = nn.Conv2d(32, 1, 1)
        self.classifierp6 = nn.Conv2d(64, 1, 1)
        self.predtrans = nn.Conv2d(1, 1, kernel_size=3, padding=1)
        self.predtrans64 = nn.Conv2d(64, 1, kernel_size=3, padding=1)



    def forward(self, in_data):
            in_data_1 = self.encoder1(in_data)
            # 64通道    256  256
            in_data_2 = self.encoder2(in_data_1)
            # 128通道  128  128 size
            in_data_4 = self.encoder4(in_data_2)
            # 256通道  64*64
            in_data_8 = self.encoder8(in_data_4)
            #  512通道  32*32
            in_data_16 = self.encoder16(in_data_8)
            # 512 通道   16*16

            in_data_1 = self.Gate1(in_data_1)
            in_data_2 = self.Gate2(in_data_2)
            in_data_4 = self.Gate3(in_data_4)
            in_data_8 = self.Gate4(in_data_8)
            in_data_16 = self.Gate5(in_data_16)


            # 1*1 CONV CHANGE CHANNEL   通道卷积
            in_data_1 = self.con_AIM1(in_data_1)
            in_data_2 = self.con_AIM2(in_data_2)
            in_data_4 = self.con_AIM3(in_data_4)
            in_data_8 = self.con_AIM4(in_data_8)
            in_data_16 = self.con_AIM5(in_data_16)
            # 64通道变32通道

            
            p5 =in_data_16
            p5 =self.gam(p5)
            p5 =self.cpa(p5)
            out_data_16 = self.upconv16(p5)


            out_data_8 = self.CSC16(in_data_8,out_data_16)
            p4 = out_data_8

            out_data_8 = self.upconv8(p4)  # 512

            out_data_4 = self.CSC8(in_data_4,out_data_8)
            p3 = out_data_4
            out_data_4 = self.upconv4(p3)  # 256


            out_data_2 = self.CSC4(in_data_2,out_data_4)
            p2 = out_data_2
            out_data_2 = self.upconv2(p2)  # 64

            out_data_1 = self.CSC2(in_data_1,out_data_2)
            f1 = out_data_1
            f1 = self.lam(f1)
            out_data_1 = self.upconv1(f1)  # 32


            out_data = self.classifier(out_data_1)
            p1 = out_data
            s1 = F.interpolate(self.predtrans(p1), size=in_data.size()[2:], mode='bilinear')
            s2 = F.interpolate(self.predtrans64(p2), size=in_data.size()[2:], mode='bilinear')
            s3 = F.interpolate(self.predtrans64(p3), size=in_data.size()[2:], mode='bilinear')
            s4 = F.interpolate(self.predtrans64(p4), size=in_data.size()[2:], mode='bilinear')
            s5 = F.interpolate(self.predtrans64(p5), size=in_data.size()[2:], mode='bilinear')


            return s1, s2, s3, s4, s5




#Res2Net-50 backbone
class A3Net_Res2Net50(nn.Module):
    def __init__(self):
        super(A3Net_Res2Net50, self).__init__()
        self.layer_rgb = Res2Net_model()

        self.upsample = cus_sample

        self.Gate1 = CBAM(64)  # 11.20 NIGHT
        self.Gate2 = CBAM(256)
        self.Gate3 = CBAM(512)
        self.Gate4 = CBAM(1024)
        self.Gate5 = CBAM(2048)

        # 1*1 conv change channel
        self.con_AIM5 = nn.Conv2d(2048, 64, 3, 1, 1)
        self.con_AIM4 = nn.Conv2d(1024, 64, 3, 1, 1)
        self.con_AIM3 = nn.Conv2d(512, 64, 3, 1, 1)
        self.con_AIM2 = nn.Conv2d(256, 64, 3, 1, 1)
        self.con_AIM1 = nn.Conv2d(64, 32, 3, 1, 1)

        # U形结构解码器
        # GAM
        self.gam = GAM(64)
        self.cpa = CPA(64)
        # SIM Module
        self.CSC16 = CSC(64)
        self.CSC8 = CSC(64)
        self.CSC4 = CSC(64)
        self.CSC2 = CSC(32)
        # LAM
        self.lam = LAM(32)

        self.upconv16 = BasicConv2d(64, 64, kernel_size=3, stride=1, padding=1)
        self.upconv8 = BasicConv2d(64, 64, kernel_size=3, stride=1, padding=1)
        self.upconv4 = BasicConv2d(64, 64, kernel_size=3, stride=1, padding=1)
        self.upconv2 = BasicConv2d(64, 32, kernel_size=3, stride=1, padding=1)
        self.upconv1 = BasicConv2d(32, 32, kernel_size=3, stride=1, padding=1)

        self.classifier = nn.Conv2d(32, 1, 1)
        self.classifierp6 = nn.Conv2d(64, 1, 1)

        self.predtrans = nn.Conv2d(1, 1, kernel_size=3, padding=1)
        self.predtrans64 = nn.Conv2d(64, 1, kernel_size=3, padding=1)

    def forward(self, in_data):
        # in_data_2 = self.div_2(in_data)
        # in_data_4 = self.div_4(in_data_2)
        # in_data_8 = self.div_8(in_data_4)
        # in_data_16 = self.div_16(in_data_8)
        # in_data_32 = self.div_32(in_data_16)
        in_data_2,in_data_4,in_data_8,in_data_16,in_data_32=self.layer_rgb(in_data)
        # print(in_data_2.shape)

        in_data_1 = self.Gate1(in_data_2)  # CBAM
        in_data_2 = self.Gate2(in_data_4)
        in_data_4 = self.Gate3(in_data_8)
        in_data_8 = self.Gate4(in_data_16)
        in_data_16 = self.Gate5(in_data_32)

        # 1*1 CONV CHANGE CHANNEL
        in_data_1 = self.con_AIM1(in_data_1)
        # print('in_data_16size {} '.format(in_data_1.shape)) ([4, 32, 128, 128])
        in_data_2 = self.con_AIM2(in_data_2)
        # print('in_data_16size {} '.format(in_data_2.shape))  ([4, 64, 64, 64])
        in_data_4 = self.con_AIM3(in_data_4)
        # print('in_data_16size {} '.format(in_data_4.shape))  ([4, 64, 32, 32])
        in_data_8 = self.con_AIM4(in_data_8)
        # print('in_data_16size {} '.format(in_data_8.shape))  ([4, 64, 16, 16])
        in_data_16 = self.con_AIM5(in_data_16)
        # print('in_data_16size {} '.format(in_data_16.shape))  ([4, 64, 8, 8])


        p5 = in_data_16
        p5 = self.gam(p5)
        p5 = self.cpa(p5)
        out_data_16 = self.upconv16(p5)

        out_data_8 = self.CSC16(in_data_8, out_data_16)
        p4 = out_data_8
        out_data_8 = self.upconv8(p4)  # 512

        out_data_4 = self.CSC8(in_data_4, out_data_8)
        p3 = out_data_4
        out_data_4 = self.upconv4(p3)  # 256

        out_data_2 = self.CSC4(in_data_2, out_data_4)
        p2 = out_data_2
        out_data_2 = self.upconv2(p2)  # 64

        out_data_1 = self.CSC2(in_data_1, out_data_2)
        f1 = out_data_1
        f1 = self.lam(f1)
        out_data_1 = self.upconv1(f1)  # 32

        out_data = self.classifier(out_data_1)
        p1 = out_data

        s1 = F.interpolate(self.predtrans(p1), size=in_data.size()[2:], mode='bilinear')
        s2 = F.interpolate(self.predtrans64(p2), size=in_data.size()[2:], mode='bilinear')
        s3 = F.interpolate(self.predtrans64(p3), size=in_data.size()[2:], mode='bilinear')
        s4 = F.interpolate(self.predtrans64(p4), size=in_data.size()[2:], mode='bilinear')
        s5 = F.interpolate(self.predtrans64(p5), size=in_data.size()[2:], mode='bilinear')

        return s1, s2, s3, s4, s5

#Swintransformer backbone
class A3Net_Swins(nn.Module):
    def __init__(self):
        super(A3Net_Swins, self).__init__()
        self.encoder = SwinTransformer(img_size=384,
                                       embed_dim=128,
                                       depths=[2, 2, 18, 2],
                                       num_heads=[4, 8, 16, 32],
                                       window_size=12)

        pretrained_dict = torch.load('./output/swin_base_patch4_window12_384_22k.pth')["model"]
        pretrained_dict = {k: v for k, v in pretrained_dict.items() if k in self.encoder.state_dict()}
        self.encoder.load_state_dict(pretrained_dict)

        self.Gate1 = CBAM(128)
        self.Gate2 = CBAM(256)
        self.Gate3 = CBAM(512)
        self.Gate4 = CBAM(1024)
        self.Gate5 = CBAM(1024)


        #1*1 conv change channel
        self.con_AIM5 = nn.Conv2d(1024, 64, 3, 1, 1)
        self.con_AIM4 = nn.Conv2d(1024, 64, 3, 1, 1)
        self.con_AIM3 = nn.Conv2d(512, 64, 3, 1, 1)
        self.con_AIM2 = nn.Conv2d(256, 64, 3, 1, 1)
        self.con_AIM1 = nn.Conv2d(128, 32, 3, 1, 1)

        # CSC Module
        # I形结构解码器
        self.DFA = DFA(64, 64)
        self.down = nn.MaxPool2d(2, 2, 0)
        self.upconv32 = BasicConv2d(64, 64, kernel_size=3, stride=1, padding=1)
        self.rfb1 = RFB(64)
        self.gd1 = GD(64)
        self.agg4 = agg(64)
        self.agg3 = agg(64)
        self.agg2 = agg(64)

        # U形结构解码器
        # GAM
        self.gam = GAM(64)
        self.cpa = CPA(64)
        # SIM Module
        self.CSC16 = CSC(64)
        self.CSC8 = CSC(64)
        self.CSC4 = CSC(64)
        self.CSC2 = CSC(32)
        # LAM
        self.lam = LAM(32)

        self.upconv16 = BasicConv2d(64, 64, kernel_size=3, stride=1, padding=1)
        self.upconv8 = BasicConv2d(64, 64, kernel_size=3, stride=1, padding=1)
        self.upconv4 = BasicConv2d(64, 64, kernel_size=3, stride=1, padding=1)
        self.upconv2 = BasicConv2d(64, 32, kernel_size=3, stride=1, padding=1)
        self.upconv1 = BasicConv2d(32, 32, kernel_size=3, stride=1, padding=1)

        self.classifier = nn.Conv2d(32, 1, 1)
        self.classifierp6 = nn.Conv2d(64, 1, 1)
        self.predtrans = nn.Conv2d(1, 1, kernel_size=3, padding=1)
        self.predtrans64 = nn.Conv2d(64, 1, kernel_size=3, padding=1)
    def forward(self, in_data):


        #1*1 CONV CHANGE CHANNEL   通道卷积
            features = self.encoder(in_data)
            x1 = features[0]
            x2 = features[1]
            x3 = features[2]
            x4 = features[3]
            x5 = features[4]



            # Due to the powerful feature extraction capability of transformers, we eliminated the cbam module in the implementation of this backbone.
            in_data_1 = self.con_AIM1(x5)
            # 64通道变32通道
            in_data_2 = self.con_AIM2(x4)
            in_data_4 = self.con_AIM3(x3)
            in_data_8 = self.con_AIM4(x2)
            in_data_16 = self.con_AIM5(x1)

            p5 = in_data_16
            p5 = self.gam(p5)
            p5 = self.cpa(p5)
            out_data_16 = self.upconv16(p5)



            out_data_8 = self.CSC16(in_data_8, out_data_16)
            p4 = out_data_8
            out_data_8 = self.upconv8(p4)  # 512

            out_data_4 = self.CSC8(in_data_4, out_data_8)
            p3 = out_data_4
            out_data_4 = self.upconv4(p3)  # 256

            out_data_2 = self.CSC4(in_data_2, out_data_4)
            p2 = out_data_2
            out_data_2 = self.upconv2(p2)  # 64


            out_data_1 = self.CSC2(in_data_1, out_data_2)
            f1 = out_data_1

            f1 = self.lam(f1)

            out_data_1 = self.upconv1(f1)  # 32


            out_data = self.classifier(out_data_1)
            p1 = out_data




            s1 = F.interpolate(self.predtrans(p1), size=in_data.size()[2:], mode='bilinear')
            s2 = F.interpolate(self.predtrans64(p2), size=in_data.size()[2:], mode='bilinear')
            s3 = F.interpolate(self.predtrans64(p3), size=in_data.size()[2:], mode='bilinear')
            s4 = F.interpolate(self.predtrans64(p4), size=in_data.size()[2:], mode='bilinear')
            s5 = F.interpolate(self.predtrans64(p5), size=in_data.size()[2:], mode='bilinear')


            return s1, s2, s3, s4, s5


if __name__ == "__main__":
    net = A3Net_Res2Net50()
    y = net(input)