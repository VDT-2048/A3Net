import torch
# import torch.nn as nn
from utils.tensor_ops import cus_sample
# import torch
# import torch.nn.functional as F
import torch.nn as nn
from torch.nn.parameter import Parameter

import numpy as np
import scipy.stats as st

def gkern(kernlen=16, nsig=3):
    interval = (2*nsig+1.)/kernlen
    x = np.linspace(-nsig-interval/2., nsig+interval/2., kernlen+1)
    kern1d = np.diff(st.norm.cdf(x))
    kernel_raw = np.sqrt(np.outer(kern1d, kern1d))
    kernel = kernel_raw/kernel_raw.sum()
    return kernel


def min_max_norm(in_):
    max_ = in_.max(3)[0].max(2)[0].unsqueeze(2).unsqueeze(3).expand_as(in_)
    min_ = in_.min(3)[0].min(2)[0].unsqueeze(2).unsqueeze(3).expand_as(in_)
    in_ = in_ - min_
    return in_.div(max_-min_+1e-8)

class RFB(nn.Module):

    def __init__(self, in_channel):

        super(RFB, self).__init__()
        out_channel = in_channel//4
        self.relu = nn.ReLU(True)

        self.branch0 = nn.Sequential(

            nn.Conv2d(out_channel, out_channel, 1),

        )#1*1卷积减小参数量

        self.branch1 = nn.Sequential(

            nn.Conv2d(out_channel, out_channel, 1),

            nn.Conv2d(out_channel, out_channel, kernel_size=(1, 3), padding=(0, 1)),

            nn.Conv2d(out_channel, out_channel, kernel_size=(3, 1), padding=(1, 0)),

            nn.Conv2d(out_channel, out_channel, 3, padding=3, dilation=3)

        )

        self.branch2 = nn.Sequential(

            nn.Conv2d(out_channel, out_channel, 1),

            nn.Conv2d(out_channel, out_channel, kernel_size=(1, 5), padding=(0, 2)),

            nn.Conv2d(out_channel, out_channel, kernel_size=(5, 1), padding=(2, 0)),

            nn.Conv2d(out_channel, out_channel, 3, padding=5, dilation=5)

        )

        self.branch3 = nn.Sequential(

            nn.Conv2d(out_channel, out_channel, 1),

            nn.Conv2d(out_channel, out_channel, kernel_size=(1, 7), padding=(0, 3)),

            nn.Conv2d(out_channel, out_channel, kernel_size=(7, 1), padding=(3, 0)),

            nn.Conv2d(out_channel, out_channel, 3, padding=7, dilation=7)

        )

        # 以上操作都没改变图片尺寸大小

        self.conv_cat = nn.Conv2d(in_channel, in_channel, 3, padding=1)
        self.sa =SpatialAttention()
        self.bn = nn.BatchNorm2d(out_channel)
        self.relu = nn.ReLU(inplace=True)
        self.conv_res = nn.Conv2d(in_channel, in_channel, 1)
    def forward(self, x,dim=True):
        x= x + x * self.sa(x)
        if dim:
            x0,x1,x2,x3 = x[:,:16,:,:], x[:,16:32,:,:],x[:,32:48,:,:] ,x[:,48:64,:,:]
        else:
            x0,x1,x2,x3 = x[:,:8,:,:], x[:,8:16,:,:],x[:,16:24,:,:] ,x[:,24:32,:,:]
        x0 = self.branch0(x0)
        x0 =self.relu(self.bn(x0))
        x1 = x1+x0
        x1 = self.branch1(x1)
        x1 =self.relu(self.bn(x1))
        x2 = x2+x1
        x2 = self.branch2(x2)
        x2 =self.relu(self.bn(x2))
        x3 =x3+x2
        x3 = self.branch3(x3)
        x3 =self.relu(self.bn(x3))
        x_cat = torch.cat((x0, x1, x2, x3), 1)
        x_cat = self.conv_cat(x_cat)
        #通道数变成原图像通道数，使用3*3卷积，没改变图像尺寸
        x = self.relu(x_cat + self.conv_res(x))
        return x

class LAM(nn.Module):
    def __init__(self, in_c):
        super(LAM, self).__init__()
        self.conv_0 = nn.Conv2d(in_c, in_c, kernel_size=1)
        self.SA = SpatialAttention()
        self.avg_pool = nn.AvgPool2d((3, 3), stride=1, padding=1)
        self.max_pool = nn.MaxPool2d((3, 3), stride=1, padding=1)
        self.maxdown = nn.MaxPool2d(2, 2, 0)
        self.avgdown2 = nn.AvgPool2d(2, 2, 0)
        self.avgdown4 = nn.AvgPool2d(4, 4, 0)
        self.upsample = cus_sample
        ratio = 8
        self.eps = 1e-5
        self.fusion = BasicConv2d(in_c, in_c, 3, padding=1)
        self.conv2 =nn.Conv2d(in_c, in_c, kernel_size=3,stride=1,padding=1)
        self.channel_add_conv = nn.Sequential(
            nn.Conv2d(in_c, in_c // ratio, kernel_size=1),
            nn.LayerNorm([in_c // ratio, 1, 1]),
            nn.ReLU(inplace=True),
            nn.Conv2d(in_c // ratio, in_c, kernel_size=1)
        )
        self.relu = nn.ReLU(inplace=True)
        self.sigmoid = nn.Sigmoid()
        self.conv_cat = BasicConv2d(2 * in_c, in_c, 3, padding=1)
        # self.bn1 = nn.BatchNorm2d(in_c)
        # self.conv_1 = nn.Conv2d(in_c, in_c, kernel_size=1, stride=1, padding=0)

    def forward(self, ftr):
        # ftr: [B, C, H, W]


        ftr_max =self.max_pool(ftr)
        context_max = (ftr_max.pow(2).sum((2, 3), keepdim=True) + self.eps).pow(0.5)
        context_max =self.channel_add_conv(context_max)
        ftr_max=ftr_max*context_max
        ftr_avg =self.avg_pool(ftr)
        context_avg = (ftr_avg.pow(2).sum((2, 3), keepdim=True) + self.eps).pow(0.5)
        context_avg =self.channel_add_conv(context_avg)
        ftr_avg =ftr_avg*context_avg
        ftr =self.sigmoid(self.conv2(self.fusion(ftr)))
        ftr_avg=ftr_avg*ftr
        ftr_max=ftr_max*ftr
        out =self.conv_cat(torch.cat((ftr_max,ftr_avg),1))

















        # up  zoom origin
        # ftr_up = self.upsample(ftr,scale_factor=2)
        # # ftr_up =self.fusion(ftr_up)
        # context_up = (ftr_up.pow(2).sum((2, 3), keepdim=True) + self.eps).pow(0.5)  # [B, C, 1, 1]
        # add_up = self.channel_add_conv(context_up)
        # ftr_up = ftr_up * add_up
        # # down
        # ftr_down = self.avgdown2(ftr)
        # # ftr_down=self.fusion(ftr_down)
        # context_down = (ftr_down.pow(2).sum((2, 3), keepdim=True) + self.eps).pow(0.5)  # [B, C, 1, 1]
        # add_down = self.channel_add_conv(context_down)
        # ftr_down = ftr_down * add_down
        # # ftr_zoom
        # # ftr_zoom = self.sigmoid(self.bn1(self.conv_1(ftr - self.avg_pool(ftr))))
        # ftr_zoom = self.sigmoid((ftr - self.avg_pool(ftr)))
        # ftr_zoomout = self.SA(self.upsample(ftr_zoom,scale_factor=2))
        # ftr_zoomin = 1 - self.SA(self.avgdown2(ftr_zoom))
        # # print(ftr_up.shape)
        # # print(ftr_zoomout.shape)
        #
        # ftr_up = self.avgdown2(ftr_up + ftr_up * ftr_zoomout)
        # ftr_down = self.upsample(ftr_down + ftr_down * ftr_zoomin,scale_factor=2)
        # # EMFI agg
        # # agg = self.fusion(torch.cat((ftr_down,ftr_zoom),1))
        # agg = self.fusion(ftr_down + ftr_up)
        # out = self.conv_cat(torch.cat((agg, ftr+ftr*ftr_zoom), 1))
        # out = out + ftr

        return out

class agg(nn.Module):
    def __init__(self,out_c):
        super(agg, self).__init__()
        self.DFA = DFA(out_c, out_c)
        # self.DFA_2 = DFA(in_c//2, out_c)
        self.maxdown = nn.MaxPool2d(2, 2, 0)
        self.avgdown = nn.AvgPool2d(2, 2, 0)
        self.upconv32 = BasicConv2d(out_c, out_c, kernel_size=3, stride=1, padding=1)
        # self.con_AIM = nn.Conv2d(in_c, out_c, 3, 1, 1)
        self.out2 = RFB(out_c)
        self.gd =GD(out_c)
        self.adp_avg = nn.AdaptiveAvgPool2d(1)
        self.upsample = cus_sample
    def forward(self, x, T=True):

        out1 =self.DFA(x)
        if T:
            out1 =self.maxdown(out1)
        else:
            out1=self.avgdown(out1)
        out1 =self.upconv32(out1)
        # out2 =self.con_AIM(x)
        out2 =self.out2(x)
        att = self.gd(out2,out1)
        return att



class GD(nn.Module):
    def __init__(self,in_c):
        super(GD, self).__init__()
        self.upsample = cus_sample
        self.conv1 = BasicConv2d(in_c, in_c, kernel_size=3, stride=1, padding=1)
        self.sa =SpatialAttention()
    def forward(self, left, right):
        if right.shape != left.shape:
            right = self.upsample(right, scale_factor=2)
        else:
            right = right

        right = self.conv1(right)

        out = left + left.mul(self.sa(right))
        return out

class DFA(nn.Module):
    def __init__(self, x, y):
        super(DFA, self).__init__()
        self.asyConv = asyConv(in_channels=x, out_channels=y, kernel_size=3, stride=1, padding=1, dilation=1, groups=1, padding_mode='zeros', deploy=False)
        self.oriConv = nn.Conv2d(x, y, kernel_size=3, stride=1, padding=1)
        self.atrConv = nn.Sequential(
            nn.Conv2d(x, y, kernel_size=3, dilation=2, padding=2, stride=1), nn.BatchNorm2d(y), nn.PReLU()
        )
        self.conv2d = nn.Conv2d(y*3, y, kernel_size=3, stride=1, padding=1)
        self.bn2d = nn.BatchNorm2d(y)
    def forward(self, f):
        p1 = self.oriConv(f)
        p2 = self.asyConv(f)
        p3 = self.atrConv(f)
        p  = torch.cat((p1, p2, p3), 1)
        p  = F.relu(self.bn2d(self.conv2d(p)), inplace=True)
        return p

import torch.nn.functional as F
import math
eps = 1e-12
class CropLayer(nn.Module):
    #   E.g., (-1, 0) means this layer should crop the first and last rows of the feature map. And (0, -1) crops the first and last columns
    def __init__(self, crop_set):
        super(CropLayer, self).__init__()
        self.rows_to_crop = - crop_set[0]
        self.cols_to_crop = - crop_set[1]
        assert self.rows_to_crop >= 0
        assert self.cols_to_crop >= 0

    def forward(self, input):
        return input[:, :, self.rows_to_crop:-self.rows_to_crop, self.cols_to_crop:-self.cols_to_crop]
class asyConv(nn.Module):

    def __init__(self, in_channels, out_channels, kernel_size, stride=1, padding=0, dilation=1, groups=1, padding_mode='zeros', deploy=False):
        super(asyConv, self).__init__()
        self.deploy = deploy
        if deploy:
            self.fused_conv = nn.Conv2d(in_channels=in_channels, out_channels=out_channels, kernel_size=(kernel_size,kernel_size), stride=stride,
                                      padding=padding, dilation=dilation, groups=groups, bias=True, padding_mode=padding_mode)
            self.initialize()
        else:
            self.square_conv = nn.Conv2d(in_channels=in_channels, out_channels=out_channels,
                                         kernel_size=(kernel_size, kernel_size), stride=stride,
                                         padding=padding, dilation=dilation, groups=groups, bias=False,
                                         padding_mode=padding_mode)
            self.square_bn = nn.BatchNorm2d(num_features=out_channels)

            center_offset_from_origin_border = padding - kernel_size // 2
            ver_pad_or_crop = (center_offset_from_origin_border + 1, center_offset_from_origin_border)
            hor_pad_or_crop = (center_offset_from_origin_border, center_offset_from_origin_border + 1)
            if center_offset_from_origin_border >= 0:
                self.ver_conv_crop_layer = nn.Identity()
                # 占位，啥也不干
                ver_conv_padding = ver_pad_or_crop
                self.hor_conv_crop_layer = nn.Identity()
                hor_conv_padding = hor_pad_or_crop
            else:
                self.ver_conv_crop_layer = CropLayer(crop_set=ver_pad_or_crop)
                ver_conv_padding = (0, 0)
                self.hor_conv_crop_layer = CropLayer(crop_set=hor_pad_or_crop)
                hor_conv_padding = (0, 0)
            self.ver_conv = nn.Conv2d(in_channels=in_channels, out_channels=out_channels, kernel_size=(3, 1),
                                      stride=stride,
                                      padding=ver_conv_padding, dilation=dilation, groups=groups, bias=False,
                                      padding_mode=padding_mode)

            self.hor_conv = nn.Conv2d(in_channels=in_channels, out_channels=out_channels, kernel_size=(1, 3),
                                      stride=stride,
                                      padding=hor_conv_padding, dilation=dilation, groups=groups, bias=False,
                                      padding_mode=padding_mode)
            self.ver_bn = nn.BatchNorm2d(num_features=out_channels)
            self.hor_bn = nn.BatchNorm2d(num_features=out_channels)
            # self.initialize()


    def forward(self, input):
        if self.deploy:
            return self.fused_conv(input)
        else:
            square_outputs = self.square_conv(input)
            square_outputs = self.square_bn(square_outputs)
            vertical_outputs = self.ver_conv_crop_layer(input)
            vertical_outputs = self.ver_conv(vertical_outputs)
            vertical_outputs = self.ver_bn(vertical_outputs)
            horizontal_outputs = self.hor_conv_crop_layer(input)
            horizontal_outputs = self.hor_conv(horizontal_outputs)
            horizontal_outputs = self.hor_bn(horizontal_outputs)
            return square_outputs + vertical_outputs + horizontal_outputs

class TransBasicConv2d(nn.Module):
    def __init__(self, in_planes, out_planes, kernel_size=2, stride=2, padding=0, dilation=1, bias=False):
        super(TransBasicConv2d, self).__init__()
        self.Deconv = nn.ConvTranspose2d(in_planes, out_planes,
                              kernel_size=kernel_size, stride=stride,
                              padding=padding, dilation=dilation, bias=False)
        self.bn = nn.BatchNorm2d(out_planes)
        self.relu = nn.ReLU(inplace=True)

    def forward(self, x):
        x = self.Deconv(x)
        x = self.bn(x)
        x = self.relu(x)
        return x
class CPA(nn.Module):
    #
    def __init__(self, in_channels):
        super(CPA, self).__init__()
        self.conv_0 = nn.Conv2d(in_channels, 2*in_channels, kernel_size=1)
        self.conv_1 = nn.Conv2d(in_channels, in_channels, kernel_size=1)
        self.conv_2 = nn.Conv2d(in_channels, in_channels//2, kernel_size=1)
        self.avgdown2 =nn.AvgPool2d(2,2,0)
        self.SA0 = SpatialAttention()
        self.SA1 = SpatialAttention()
        self.SA2 = SpatialAttention()
        self.conv_0_out = nn.Conv2d(2*in_channels, in_channels, kernel_size=1)
        self.conv_2_out = nn.Conv2d(in_channels//2, in_channels, kernel_size=1)
        self.conv_cat =nn.Conv2d(2*in_channels,in_channels,3,padding=1)
        self.conv_cat_2 = nn.Conv2d(3*in_channels, in_channels, 3,padding=1)
        self.upsample = cus_sample
    def forward(self, ftr):
        # ftr: [B, C, H, W]
        d0 = self.conv_0(self.upsample(ftr,scale_factor=2)) # [B, 2C, 2H, 2W]
        d1 = self.conv_1(ftr) # [B, C, H, W]
        d2 = self.conv_2(self.avgdown2(ftr)) # [B, C/2, H/2, W/2]
        # level-2
        d0 = d0 + d0 * self.SA0(d0)
        d1 = d1 + d1 * self.SA1(d1)
        d2 = d2 + d2 * self.SA2(d2)
        d0 =self.conv_0_out(self.avgdown2(d0))  # [B, 2C, 2H, 2W]
        d1 =self.conv_1(d1) # [B, C, H, W]
        d2 =self.conv_2_out(self.upsample(d2,scale_factor=2))
        out =self.conv_cat(torch.cat((d1,d2),1))
        out = out+out*self.SA0(out)
        out = torch.cat((d0,out,d2), 1)
        out = self.conv_cat_2(out)
        return out
class GAM(nn.Module):
    # Global
    def __init__(self, in_channels):
        super(GAM, self).__init__()
        # inter_channels = in_channels // squeeze_ratio # reduce computation load
        self.conv_q = nn.Conv2d(in_channels, in_channels, kernel_size=1)
        self.conv_k = nn.Conv2d(in_channels, in_channels, kernel_size=1)
        self.conv_v = nn.Conv2d(in_channels, in_channels, kernel_size=1)
        self.delta = nn.Parameter(torch.Tensor([0.1])) # initiate as 0.1
        self.avg_pool = nn.AvgPool2d((3, 3), stride=1,padding=1)
        self.amg_pool = nn.MaxPool2d((3, 3), stride=1,padding=1)
        self.conv_rbc = BasicConv2d(in_channels, in_channels, kernel_size=3, stride=1, padding=1)
        self.conv_rbc_2 = BasicConv2d(2 * in_channels, in_channels, kernel_size=3, stride=1, padding=1)
    def forward(self, ftr):
        B, C, H, W = ftr.size()
        P = H * W
        ftr_q = self.conv_q(ftr).view(B, -1, P).permute(0, 2, 1) # [B, P, C']
        ftr_k = self.conv_k(ftr).view(B, -1, P) # [B, C', P]
        ftr_v = self.conv_v(ftr).view(B, -1, P) # [B, C, P]
        weights = F.softmax(torch.bmm(ftr_q, ftr_k), dim=1) # column-wise softmax, [B, P, P]
        G = torch.bmm(ftr_v, weights).view(B, C, H, W)
        # energy_new = torch.max(G, -1, keepdim=True)[0].expand_as(G) - G
        out = self.delta * G + ftr
        out =self.conv_rbc(out)
        out =torch.sigmoid(out)
        ftr_avg = self.avg_pool(ftr)
        ftr_max = self.amg_pool(ftr)
        ftr_avg =ftr_avg.mul(out)
        ftr_max =ftr_max.mul(out)
        out =torch.cat((ftr_max,ftr_avg),1)
        out = self.conv_rbc_2(out)

        return out
class CSC(nn.Module):
    def __init__(self, left_channel):
        super(CSC, self).__init__()
        self.conv1 = BasicConv2d(left_channel, left_channel, kernel_size=3, stride=1, padding=1)
        self.conv2 = nn.Conv2d(left_channel, left_channel, kernel_size=3, stride=1, padding=1)
        self.conv_cat = BasicConv2d(2*left_channel, left_channel, kernel_size=3,stride=1, padding=1)
        self.conv_cat_2 = BasicConv2d(3*left_channel, left_channel, kernel_size=3, stride=1, padding=1)
        self.avg_pool = nn.AvgPool2d((3, 3), stride=1,padding=1)
        self.sigmoid = nn.Sigmoid()
        self.upsample = cus_sample
        self.SA =SpatialAttention()
    def forward(self, left, right):
        if right.shape != left.shape:
            right = self.upsample(right, scale_factor=2)  # right 上采样
        else:
            right = right
        # out =right
        # baseline

        # 加SIM模块
        right = self.conv1(right)
        out = self.conv_cat(torch.cat((left,right),1))
        out_g = self.conv2(out)
        out_g =self.avg_pool(out_g)
        out_g =self.sigmoid(out_g)
        right =self.conv2(right)*out_g
        left =self.conv2(left)*out_g
        out =self.conv_cat_2(torch.cat((left,right,out),1))
        out_g2 =self.sigmoid(self.conv2(out-self.avg_pool(out)))
        out =self.conv2(out)*out_g2

        return out
#CBAM
class CBAM(nn.Module):
    def __init__(self, in_channel):
        super(CBAM, self).__init__()
        self.sa = SpatialAttention()
        self.ca = ChannelAttention(in_channel)

    def forward(self, x):
        # CA = x.mul(self.ca(x))
        # # 元素级别点对点相乘
        # SA = CA.mul(self.sa(CA))


        x1_ca = x.mul(self.ca(x))
        x1_sa = x1_ca.mul(self.sa(x1_ca))
        x = x + x1_sa
        return x

class BasicConv2d(nn.Module):
    def __init__(self, in_planes, out_planes, kernel_size, stride=1, padding=0, dilation=1):
        super(BasicConv2d, self).__init__()
        self.conv = nn.Conv2d(in_planes, out_planes,
                              kernel_size=kernel_size, stride=stride,
                              padding=padding, dilation=dilation, bias=False)
        self.bn = nn.BatchNorm2d(out_planes)
        self.relu = nn.ReLU(inplace=True)

    def forward(self, x):
        x = self.conv(x)
        x = self.bn(x)
        x = self.relu(x)
        return x

class ChannelAttention(nn.Module):   #CA
    def __init__(self, in_planes):
        super(ChannelAttention, self).__init__()

        self.max_pool = nn.AdaptiveMaxPool2d(1)

        self.fc1 = nn.Conv2d(in_planes, in_planes // 16, 1, bias=False)
        self.relu1 = nn.ReLU()
        self.fc2 = nn.Conv2d(in_planes // 16, in_planes, 1, bias=False)

        self.sigmoid = nn.Sigmoid()

    def forward(self, x):
        max_out = self.fc2(self.relu1(self.fc1(self.max_pool(x))))
        out = max_out
        return self.sigmoid(out)


class SpatialAttention(nn.Module):  #SA
    def __init__(self, kernel_size=7):
        super(SpatialAttention, self).__init__()

        assert kernel_size in (3, 7), 'kernel size must be 3 or 7'
        padding = 3 if kernel_size == 7 else 1

        self.conv1 = nn.Conv2d(1, 1, kernel_size, padding=padding, bias=False)
        self.sigmoid = nn.Sigmoid()

    def forward(self, x):
        max_out, _ = torch.max(x, dim=1, keepdim=True)
        x = max_out
        x = self.conv1(x)
        return self.sigmoid(x)

if __name__ == "__main__":
    module = CSC(64)
    # print([(name, params.size()) for name, params in module.named_parameters()])
